import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.layers import Input, Embedding, Dot, Dense, Flatten
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.model_selection import train_test_split

pd.options.display.max_columns = None

import warnings
def ignore_warn(*args, **kwargs):
    pass
warnings.warn = ignore_warn



def deep_matrix_factorization(data, test_data, column, embedding_dim=10, hidden_units=10, learning_rate=0.01, epochs=100, batch_size=2):
    # Split the data into user indices, item indices, and ratings
    user_indices = data[:, 0]
    item_indices = data[:, 1]
    ratings = data[:, 2]

    # Create a set of unique user and item values
    unique_users = np.unique(user_indices)
    unique_items = np.unique(item_indices)

    # Mapping function to convert user and item values to the range [0, num_users/items]
    user_map = {user: i for i, user in enumerate(unique_users)}
    item_map = {item: i for i, item in enumerate(unique_items)}

    # Convert the user and item indices to mapped indices
    mapped_user_indices = np.vectorize(lambda x: user_map[x])(user_indices)
    mapped_item_indices = np.vectorize(lambda x: item_map[x])(item_indices)

    # Split the data into training and testing sets
    # train_data, test_data = train_test_split(data, test_size=0.2, random_state=42)

    # Define the input layers
    user_input = Input(shape=(1,))
    item_input = Input(shape=(1,))

    # User embedding layer
    user_embedding = Embedding(len(unique_users), embedding_dim)(user_input)
    user_embedding = Flatten()(user_embedding)

    # Item embedding layer
    item_embedding = Embedding(len(unique_items), embedding_dim)(item_input)
    item_embedding = Flatten()(item_embedding)

    # Concatenate the user and item embeddings
    concatenated_embeddings = tf.concat([user_embedding, item_embedding], axis=1)

    # Hidden layers
    hidden_layer = Dense(hidden_units, activation='relu')(concatenated_embeddings)
    output_layer = Dense(1)(hidden_layer)

    # Model definition
    model = Model(inputs=[user_input, item_input], outputs=output_layer)

    # Compile the model
    model.compile(optimizer=Adam(learning_rate=learning_rate), loss='mean_squared_error')

    # Train the model
    model.fit([mapped_user_indices, mapped_item_indices], ratings, epochs=epochs, batch_size=batch_size, verbose=1)

    # Test the model
    test_user_indices = test_data[:, 0]
    test_item_indices = test_data[:, 1]
    test_ratings = test_data[:, column]

    mapped_test_user_indices = np.vectorize(lambda x: user_map[x])(test_user_indices)
    mapped_test_item_indices = np.vectorize(lambda x: item_map[x])(test_item_indices)

    predictions = model.predict([mapped_test_user_indices, mapped_test_item_indices])

    return test_ratings,predictions
    # Calculate the mean squared error
    # mse = mean_squared_error(test_ratings, predictions)
    # print(test_ratings)
    # print(predictions)
    #
    # return mse


# defining colnames and reading the data file
colNames = ['hotel_id','user_id','Overall_rating']

#reading the data file
data_full = pd.read_csv("trip_advisor.csv")
#printing shape of data
print("shape of Actual data : ", data_full.shape)
#printing sample of dataset
print("Full data look : \n", data_full.head())
#printing unique item id and userid
print( "The data has ", len(data_full.hotel_id.unique()), " uniques movie id and", len(data_full.user_id.unique()),"unique users")

#coverted the dataframe into array
data = np.array(data_full[['user_id','hotel_id','Overall_rating']])

#printing the dataArray
print("Coverted to Single Critera : \n",pd.DataFrame(data,columns=colNames).head())

#spliting the dataArray
train_data, test_data = train_test_split(data, test_size=0.2, random_state=42)


# Extract user and item indices
test_user_indices = test_data[:, 0]
test_item_indices = test_data[:, 1]

# Creating Dummy frame, which will store the predicted ratings returning from DeepMF
actual_pred_matrix =  np.column_stack((test_user_indices, test_item_indices))

#calling the deep_matrix factoriztion, Passing <whole data,test_Data and the rating column number> as arguments
Actual_test_ratings, predictions = deep_matrix_factorization(data,test_data,2)

#appending Actual_Test_ratings and Predicted_Ratings to dummy frame
actual_pred_matrix = np.column_stack((actual_pred_matrix, Actual_test_ratings))
actual_pred_matrix = np.column_stack((actual_pred_matrix, predictions))

#printing the userid,itemid,actual,prediacted
criteria_column = ['User_id','Hotel_id','Actual_rating','Predicted_rating']

#to print the whole data uncomment below line
# print(f"Actual and predicted values : \n",pd.DataFrame(actual_pred_matrix,columns=criteria_column).to_markdown())

#pinting sample of the actual and predicted ratings
print(f"Actual and predicted values : \n",pd.DataFrame(actual_pred_matrix,columns=criteria_column).head())

#calculating the error and printing.
mse = mean_squared_error(Actual_test_ratings, predictions)
rmse = np.sqrt(mse)
mae = mean_absolute_error(Actual_test_ratings, predictions)
print(f"Mean Squared Error: {mse:.5f}")
print(f"Root Mean Squared Error: {rmse:.5f}")
print(f"Mean Absolute error : : {mae:.5f}")

