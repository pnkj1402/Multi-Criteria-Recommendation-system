import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
from surprise import Reader, Dataset
from surprise.model_selection import cross_validate
from surprise import SVD, SVDpp,accuracy,NMF
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Lasso,LinearRegression
from sklearn.model_selection import GridSearchCV
import random
random.seed(108)

import warnings
def ignore_warn(*args, **kwargs):
    pass
warnings.warn = ignore_warn




#defining colnames and reading the data file
colNames = ['user_id','criterion1', 'criterion2', 'criterion3', 'criterion4', 'overall', 'movie_id', 'number']
data_full = pd.read_csv("data_movies.txt", sep ="\t",header= None , names= colNames )
print("shape of Actual data : ", data_full.shape)
print("Full data look : \n", data_full.head())


print( "The data has ", len(data_full.movie_id.unique()), " uniques movie id and", len(data_full.user_id.unique()),"unique users")

#Scaling the data values for Moviedata from (1,13) to (1,5)
#Scaling the data values for tripadvisor from (1,6) to (1,5)
scaler = MinMaxScaler(feature_range=(1, 5))
data_full['criterion1'] = scaler.fit_transform(data_full['criterion1'].values[:, None].astype(float))
data_full['criterion2'] = scaler.fit_transform(data_full['criterion2'].values[:, None].astype(float))
data_full['criterion3'] = scaler.fit_transform(data_full['criterion3'].values[:, None].astype(float))
data_full['criterion4'] = scaler.fit_transform(data_full['criterion4'].values[:, None].astype(float))
data_full['overall'] = scaler.fit_transform(data_full['overall'].values[:, None].astype(float))


#seperating features columns and target value
X = data_full[['user_id','criterion1', 'criterion2', 'criterion3', 'criterion4', 'movie_id']]
y = data_full['overall']

#splitting data
full_train, full_test, y_train, y_test = train_test_split(X, y, test_size=0.30, random_state=42)
print("Train Size len : ",full_train.shape, "Test size len : ", full_test.shape )

# creating a dictionary of <df : criteria> individual criteria values
list_of_criteria_train = {}
list_of_criteria_test = {}
dfs = ('df1', 'df2', 'df3', 'df4')
criterion = ('criterion1', 'criterion2', 'criterion3', 'criterion4')
for df, ctn in zip(dfs, criterion):
    print(df, ctn)
    full_dataset_train = full_train[['user_id','movie_id',ctn]]
    list_of_criteria_train[df] = full_dataset_train
    print("Train : ",list_of_criteria_train[df].shape)
    full_dataset_test = full_test[['user_id','movie_id',ctn]]
    list_of_criteria_test[df] = full_dataset_test
    print("Test : ",list_of_criteria_test[df].shape)


# Individual criteria SVD predictions #######################
def compute_svd_predictions(criteria_data_train, criteria_data_test):

    reader = Reader()
    svd = SVD(n_epochs = 100, verbose = True, lr_all = 0.0001 )
    # dataset creation

    criteria_data_train.columns = ['userId', 'movieId', 'rating']
    criteria_data_test.columns = ['userId', 'movieId', 'rating']

    #prepering training data and fitting in model
    train_data = Dataset.load_from_df(criteria_data_train, reader=reader)
    fullTrainSet = train_data.build_full_trainset()
    svd.fit(fullTrainSet)

    #preparing test data
    test_data = Dataset.load_from_df(criteria_data_test, reader=reader)
    fullTestSet = test_data.build_full_trainset()
    testing_data = fullTestSet.build_testset()

    #making prediction from test data
    pred = svd.test(testing_data)
    # print(pred)
    pdf = pd.DataFrame(pred)
    print("X_Test predicted Data : \n", pdf.head())

    return pdf


# Creating frame for the prediction
predicted_dataset = list_of_criteria_test['df1'][['user_id','movie_id']]
# print(predicted_dataset.shape)
# print("before calling  : \n ",predicted_dataset.head())


#calling svd prediction for every criteria
for key in list_of_criteria_train.keys():
    print(key)
    pred_data = compute_svd_predictions(list_of_criteria_train[key],list_of_criteria_test[key])
    pred_data.columns =['user_id', 'movie_id', 'Orating', key,'details']
    new_data = pred_data.drop(columns=['Orating','details'])
    new_data = new_data.set_index(['user_id','movie_id'])
    # print(new_data.head())
    #appending the predicted data in frame
    predicted_dataset = new_data.combine_first(predicted_dataset.set_index(['user_id','movie_id'])).reset_index()
    print(key, " predicted_Dataset \n ", predicted_dataset)

print("All X_test predicted data shape : ", predicted_dataset.shape)
print("X_Test full predicted view : \n",predicted_dataset.head())


print("################### Aggregator function in working #####################")

training_data = full_train[['criterion1','criterion2','criterion3','criterion4']]

testing_data = full_test[['criterion1','criterion2','criterion3','criterion4']]

predicted_dataset.columns = ['user_id','movie_id','criterion1','criterion2','criterion3','criterion4']
predicting_data = predicted_dataset[['criterion1','criterion2','criterion3','criterion4']]


lasso=Lasso()
parameters={'alpha':[1e-15,1e-10,1e-8,1e-3,1e-2,1,5,10,20,30,35,40,45,50,55,100]}
lasso_regressor=GridSearchCV(lasso,parameters,scoring='neg_mean_squared_error',cv=5,verbose = True)
lasso_regressor.fit(training_data,y_train)
print(lasso_regressor.best_params_)
# print(lasso_regressor.best_score_)


lasso_best = Lasso(alpha=lasso_regressor.best_params_['alpha'])    #taking best alpha and building model

# Fit the lasso model with the best alpha on the training data
lasso_best.fit(training_data, y_train)


predicted_y_test=lasso_regressor.predict(predicting_data)  #predicted X test predicting the y_test

# print("Liner \n ", predicted_y_test_Liner)
# print("laasso \n ", predicted_y_test)

y_test = y_test.to_numpy()
MSE_Lasso = np.square(np.subtract(y_test,predicted_y_test)).mean()
RMSE_lasso = np.sqrt(np.mean((y_test-predicted_y_test)**2))

print("MSE of the aggregated model, Lasso : ", MSE_Lasso)
print("RMSE of the aggregated model, Lasso : ", RMSE_lasso)
print("MAE  of the aggregated model, Lasso : ", mean_absolute_error(y_test, predicted_y_test))



print("\n###### Linear Regression ############ \n")

# Create a Linear Regression model
liner_best = LinearRegression()


# Fit the lasso model with the best alpha on the training data
liner_best.fit(training_data, y_train)

# predicted X test predicting the y_test
predicted_y_test=liner_best.predict(predicting_data)

# y_test = y_test.to_numpy()
MSE_Linear = np.square(np.subtract(y_test,predicted_y_test)).mean()
RMSE_Linear = np.sqrt(np.mean((y_test-predicted_y_test)**2))

print("MSE of the aggregated model, Linear : ", MSE_Linear)
print("RMSE of the aggregated model, Linear : ", RMSE_Linear)
print("MAE  of the aggregated model, Linear : ", mean_absolute_error(y_test, predicted_y_test))





#############Output########
