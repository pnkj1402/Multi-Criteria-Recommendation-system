import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.layers import Input, Embedding, Dot, Dense, Flatten
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.model_selection import train_test_split

pd.options.display.max_columns = None

import warnings
def ignore_warn(*args, **kwargs):
    pass
warnings.warn = ignore_warn



def deep_matrix_factorization(data, test_data, column, embedding_dim=10, hidden_units=10, learning_rate=0.01, epochs=50, batch_size=2):
    # Split the data into user indices, item indices, and ratings
    user_indices = data[:, 0]
    item_indices = data[:, 1]
    ratings = data[:, 2]

    # Create a set of unique user and item values
    unique_users = np.unique(user_indices)
    unique_items = np.unique(item_indices)

    # Mapping function to convert user and item values to the range [0, num_users/items]
    user_map = {user: i for i, user in enumerate(unique_users)}
    item_map = {item: i for i, item in enumerate(unique_items)}

    # Convert the user and item indices to mapped indices
    mapped_user_indices = np.vectorize(lambda x: user_map[x])(user_indices)
    mapped_item_indices = np.vectorize(lambda x: item_map[x])(item_indices)

    # Split the data into training and testing sets
    # train_data, test_data = train_test_split(data, test_size=0.2, random_state=42)

    # Define the input layers
    user_input = Input(shape=(1,))
    item_input = Input(shape=(1,))

    # User embedding layer
    user_embedding = Embedding(len(unique_users), embedding_dim)(user_input)
    user_embedding = Flatten()(user_embedding)

    # Item embedding layer
    item_embedding = Embedding(len(unique_items), embedding_dim)(item_input)
    item_embedding = Flatten()(item_embedding)

    # Concatenate the user and item embeddings
    concatenated_embeddings = tf.concat([user_embedding, item_embedding], axis=1)

    # Hidden layers
    hidden_layer = Dense(hidden_units, activation='relu')(concatenated_embeddings)
    output_layer = Dense(1)(hidden_layer)

    # Model definition
    model = Model(inputs=[user_input, item_input], outputs=output_layer)

    # Compile the model
    model.compile(optimizer=Adam(learning_rate=learning_rate), loss='mean_squared_error')

    # Train the model
    model.fit([mapped_user_indices, mapped_item_indices], ratings, epochs=epochs, batch_size=batch_size, verbose=1)

    # Test the model
    test_user_indices = test_data[:, 0]
    test_item_indices = test_data[:, 1]
    test_ratings = test_data[:, column]

    mapped_test_user_indices = np.vectorize(lambda x: user_map[x])(test_user_indices)
    mapped_test_item_indices = np.vectorize(lambda x: item_map[x])(test_item_indices)

    predictions = model.predict([mapped_test_user_indices, mapped_test_item_indices])

    return test_ratings,predictions
    # Calculate the mean squared error
    # mse = mean_squared_error(test_ratings, predictions)
    # print(test_ratings)
    # print(predictions)
    #
    # return mse

# # Sample data
# data = np.array([
# [101,2225,4,1,4,4,4],
# [101,5079,4,3,3,2,3],
# [101,8440,4,3,4,3,3],
# [101,4592,5,6,6,5,5],
# [101,5901,6,6,6,1,6],
# [101,4367,5,5,5,5,5],
# [101,3619,1,1,1,1,1],
# [101,8210,1,1,1,1,1],
# [101,7802,4,6,5,2,3],
# [101,7928,6,6,6,6,6],
# [101,4210,6,1,6,5,6],
# [101,4248,6,6,6,6,6],
# [101,2549,1,1,1,1,1],
# [101,9373,4,6,6,6,6],
# [101,1608,5,5,5,1,5],
# [101,6939,5,5,5,5,5],
# [101,3976,4,6,5,4,4]  # User 2 rates Item 2
# ])
# #
# print("data : \n", data)
# defining colnames and reading the data file
colNames = ['hotel_id','user_id', 'Rooms_rating', 'Location_rating', 'Cleanliness_rating', 'Overall_rating', 'Service_rating']
data_full = pd.read_csv("trip_advisor.csv")
print("shape of Actual data : ", data_full.shape)
print("Full data look : \n", data_full.head())
print( "The data has ", len(data_full.hotel_id.unique()), " uniques movie id and", len(data_full.user_id.unique()),"unique users")

data = np.array(data_full[['user_id','hotel_id','Rooms_rating', 'Location_rating', 'Cleanliness_rating', 'Service_rating', 'Overall_rating']])




train_data, test_data = train_test_split(data, test_size=0.2, random_state=42)

x_train = train_data[:,2:6]
y_train = train_data[:,6]

x_test = test_data[:,2:6]
y_test =  test_data[:,6]

# print("x_train : \n", x_train)
# print("y_train : \n", y_train)
# print("x_test : \n", x_test)
# print("y_test : \n", y_test)


# Extract user and item indices
test_user_indices = test_data[:, 0]
test_item_indices = test_data[:, 1]

# Creating frame for the prediction
actual_pred_matrix =  np.column_stack((test_user_indices, test_item_indices))
user_item = np.column_stack((data[:,0], data[:,1]))


for column in range(2,6):
    print("Column number : ", column-1)
    passing_data = np.column_stack((user_item, data[:,column]))
    test_ratings, predictions = deep_matrix_factorization(passing_data,test_data,column)
    actual_pred_matrix = np.column_stack((actual_pred_matrix, test_ratings))
    actual_pred_matrix = np.column_stack((actual_pred_matrix, predictions))
    mse = mean_squared_error(test_ratings, predictions)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(test_ratings, predictions)
    print(f"Mean Squared Error: {mse:.5f}")
    print(f"Root Mean Squared Error: {rmse:.5f}")
    print(f"Mean Absolute error : : {mae:.5f}")

criteria_column = ['Uid','Hid','Rr','Pre_Rr', 'Lr','Pre_Lr', 'Cr','Pre_Cr', 'Sr','Pre_Sr']
print(f"Actual and predicted values : \n",pd.DataFrame(actual_pred_matrix,columns=criteria_column).to_markdown())

pred_x_test = actual_pred_matrix[:,(3,5,7,9)]

mse = mean_squared_error(x_test, pred_x_test)
rmse = np.sqrt(mse)
mae = mean_absolute_error(x_test, pred_x_test)
print(f"\nMean Squared Error of All ratings: {mse:.5f}")
print(f"Root Mean Squared Error of All ratings: {rmse:.5f}")
print(f"Mean Absolute error of All ratings: {mae:.5f}")


print("\n##################  Performance c1,c2,c3,c4 ->>> Target ####################################### \n")

print("\n###### Lasso Regression ############ \n\n")
from sklearn.linear_model import Lasso, LinearRegression
from sklearn.model_selection import GridSearchCV

lasso=Lasso()
parameters={'alpha':[1e-15,1e-10,1e-8,1e-3,1e-2,1,5,10,20,30,35,40,45,50,55,100]}
lasso_regressor=GridSearchCV(lasso,parameters,scoring='neg_mean_squared_error',cv=2,verbose = True)
lasso_regressor.fit(x_train,y_train)
print("Lasso parameter : ",lasso_regressor.best_params_)
# print(lasso_regressor.best_score_)


lasso_best = Lasso(alpha=lasso_regressor.best_params_['alpha'])    #taking best alpha and building model

# Fit the lasso model with the best alpha on the training data
lasso_best.fit(x_train, y_train)

# predicted X test predicting the y_test
predicted_y_test=lasso_regressor.predict(pred_x_test)

MSE_Lasso = np.square(np.subtract(y_test,predicted_y_test)).mean()
RMSE_lasso = np.sqrt(np.mean((y_test-predicted_y_test)**2))

print("MSE of the aggregated model, Lasso : ", MSE_Lasso)
print("RMSE of the aggregated model, Lasso : ", RMSE_lasso)
print("MAE  of the aggregated model, Lasso : ", mean_absolute_error(y_test, predicted_y_test))


print("\n###### Linear Regression ############ \n")

# Create a Linear Regression model
liner_best = LinearRegression()

# Fit the lasso model with the best alpha on the training data
liner_best.fit(x_train, y_train)

# predicted X test predicting the y_test
predicted_y_test=liner_best.predict(pred_x_test)

MSE_Linear = np.square(np.subtract(y_test,predicted_y_test)).mean()
RMSE_Linear = np.sqrt(np.mean((y_test-predicted_y_test)**2))

print("MSE of the aggregated model, Linear : ", MSE_Linear)
print("RMSE of the aggregated model, Linear : ", RMSE_Linear)
print("MAE  of the aggregated model, Linear : ", mean_absolute_error(y_test, predicted_y_test))

